#ifndef G4HALFSPACESPECIALQUADRIC_HH
#define G4HALFSPACESPECIALQUADRIC_HH
#include "G4HalfSpaceQuadric.hh"

class G4HalfSpaceSpecialQuadric: public G4HalfSpaceQuadric
{
public:
    G4HalfSpaceSpecialQuadric();

};

#endif // G4HALFSPACESPECIALQUADRIC_HH
