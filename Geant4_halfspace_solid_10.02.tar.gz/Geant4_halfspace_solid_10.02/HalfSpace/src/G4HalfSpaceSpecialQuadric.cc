#include "G4HalfSpaceSpecialQuadric.hh"

G4HalfSpaceSpecialQuadric::G4HalfSpaceSpecialQuadric()
{
}
